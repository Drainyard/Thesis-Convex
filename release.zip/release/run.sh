#!/bin/bash

./build.sh
pushd build

./main

popd

